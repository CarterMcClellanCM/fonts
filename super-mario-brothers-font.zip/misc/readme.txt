How to use:
To install the font, just extract the file into C:\Windows\Fonts